# Auto Filter Bot — Koyeb Deployment Guide

## 1. Code GitHub par push karo
Ye poora folder (bot.py, requirements.txt, Dockerfile) ek GitHub repo me daalo.

## 2. Koyeb par naya app banao
1. https://app.koyeb.com par login karo
2. **Create App** → **GitHub** select karo → apni repo choose karo
3. Build method: **Dockerfile** (auto-detect ho jayega)
4. Service type: **Web Service**
5. Port: **8000**

## 3. Environment Variables (Koyeb dashboard → Environment Variables)

| Key              | Value                                                        |
|-------------------|---------------------------------------------------------------|
| API_ID            | apna Telegram API ID (my.telegram.org se)                     |
| API_HASH          | apna API Hash                                                  |
| BOT_TOKEN         | BotFather se mila token                                        |
| BOT_USERNAME      | bot ka username, bina @ ke (jaise: MyAutoFilterBot)            |
| DB_CHANNEL        | apne database channel ki ID (-100...)                          |
| POST_CHANNEL      | jis channel me auto-post (poster+details) jayega uski ID       |
| MONGO_URI         | MongoDB Atlas connection string                                 |
| TMDB_API_KEY      | themoviedb.org se free API key                                  |
| WATCH_REGION      | OTT provider ke liye country code (default IN)                  |
| POWERED_BY_TEXT   | post ke neeche dikhne wala text (jaise: My Movie Zone)          |
| POWERED_BY_LINK   | us text ka link (jaise: https://t.me/apna_channel)              |
| REQUEST_CHANNEL   | private channel ki ID jahan sirf admin dekh sake — movie requests wahan aayengi |
| OWNER_ID          | aapka apna Telegram user ID (bot ki security ke liye zaroori)   |
| SPAM_LOG_CHANNEL  | private channel ki ID jahan spam alerts (kisne kya kiya) aayenge |
| MUTE_MINUTES      | kitni der mute karna hai (default: 30)                           |
| LOG_CHANNEL       | private channel ki ID jahan naye users/groups ka log aayega     |
| TOTAL_STORAGE_MB  | aapke MongoDB cluster ka total storage quota MB me (default: 512, Atlas free tier) |
| FORCE_SUB_CHANNEL | private channel ki ID jise user join kiye bina bot use nahi kar payega |

⚠️ Ye values kabhi bhi seedhe code me mat likho — hamesha environment variables se hi daalo.

## 4. Deploy
Deploy dabao. Logs me "Bot starting..." dikhega matlab bot chal raha hai.
`https://<your-app>.koyeb.app/` khol ke check karo — "Auto Filter Bot is running!" dikhna chahiye.

## 5. Zaroori setup steps
- Bot ko **DB_CHANNEL** me admin banao (files padhne ke liye).
- Bot ko **POST_CHANNEL** me bhi admin banao (post karne + edit karne ke liye).
- Bot ko jis group me use karna hai wahan add karo.
- **BOT_USERNAME** sahi hona chahiye warna deep-links (Click Here) kaam nahi karenge.

## Kaise kaam karta hai (Auto Poster)
Jab bhi **DB_CHANNEL** me naya video/file aata hai, bot uske caption/filename se:

1. **Quality** detect karta hai (480p, 720p, 720p HEVC, 1080p 10bit, 2160p/4K, Pre-HD, HDTC, CAM, HQ...)
2. **Source** detect karta hai (WEB-DL, BluRay, WebRip, HDRip, DVDRip, HDTC, CAM, Pre-HD, HQ)
3. **Audio languages** detect karta hai — Hindi, English, Tamil, Telugu, Kannada, Malayalam, Marathi, Bengali, Punjabi, Gujarati, Urdu, Bhojpuri (jitni bhi caption me mile, sab)
4. **TMDB** se **genres**, **OTT platform**, aur **landscape poster** fetch karta hai
5. **POST_CHANNEL** me structured post bhejta hai:

   ```
   🎬 Movie Name Year
   ────•˚•── ✦ ──•˚•────
   🔊 ᴀᴜᴅɪᴏ  : Hindi, English
   🎭 ɢᴇɴʀᴇs : Action
   🍿 ᴏᴛᴛ : Amazon Prime Video
   🚀 ǫᴜᴀʟɪᴛʏ : WEB-DL
   ────•˚•── ✦ ──•˚•────

   480p : [Click Here](deep-link)

   720p : [Click Here](deep-link)

   1080p : [Click Here](deep-link)

   💢 ᴘᴏᴡᴇʀᴇᴅ ʙʏ : [Your Channel](link) 🤞
   ```

6. Har **"Click Here"** link us **exact file** ka deep-link hai — jab user click karega,
   bot uske PM me wahi specific file bhej dega (`/start file_<id>` ke through).
7. Agar **same movie** ki **nayi quality** baad me aati hai, to purana post edit ho jaata hai
   (naya post nahi banta) — quality list me nayi line add ho jaati hai.

## Poster kaise attach hota hai
Poster hamesha **landscape (backdrop)** hota hai — kabhi bhi portrait poster use nahi hoga —
aur **HD (`original`)** quality me fetch hota hai. Bot pehle TMDB ke `/images` endpoint se
sabhi backdrops check karta hai aur sabse **high-resolution** wala pick karta hai; agar wo na
mile to search result ke backdrop par fallback karta hai.

Poster ka link seedha Telegram ko nahi diya jaata — bot pehle poster ko apne server par
**download** karta hai, phir ek **actual photo file** ki tarah upload karke bhejta hai.
Isse do faayde hain:
1. Poster aur text ek hi post me **chipka hua** dikhta hai (photo + caption), sirf link-preview
   card jaisa nahi.
2. Original TMDB poster link kabhi bhi message me expose nahi hota — koi bhi user seedha wo
   raw link copy karke reuse nahi kar sakta.

## Force Subscribe (Join Request)
User jab tak aapke **private channel** ko join nahi karta, bot use nahi kar payega. Jaise hi
wo `/start` karta hai (ya file link click karta hai), agar wo channel me nahi hai to:

```
🔒 Access Denied

• Private Channel: Access requires approval. Send join request.

✅ After joining, please press /start again.

[🔐 Send Join Request]
```

- Button dabate hi Telegram **join request** bhej deta hai (private channel me seedha add
  nahi hota — pehle **admin ki manual approval** lagti hai, jo aap channel ke "Join Requests"
  section me kar sakte ho)
- Approve hone ke baad user `/start` dobara karega to bot normal kaam karega

**Setup:**
1. Ek naya **private channel** banao
2. Channel Settings → "**Approve New Members**" ON karo (taaki join request wala flow chale)
3. Bot ko us channel me **admin** banao (invite links banane ke liye)
4. Uski chat ID `FORCE_SUB_CHANNEL` env variable me daal do

Agar ye feature nahi chahiye to `FORCE_SUB_CHANNEL` env var **khaali/0** rehne do — bot bina
kisi restriction ke normal kaam karega.

## Live /stats Command (owner-only)
`OWNER_ID` wala user jab `/stats` bhejta hai to ye live data dikhta hai:

```
╭────[ 🗃 ᴅᴀᴛᴀʙᴀsᴇ 🗃 ]────⍟
│
├⋟ ᴀʟʟ ᴜsᴇʀs ⋟ 1354
├⋟ ᴀʟʟ ɢʀᴏᴜᴘs ⋟ 15
├⋟ ᴘʀᴇᴍɪᴜᴍ ᴜꜱᴇʀꜱ ⋟ 0
├⋟ ᴀʟʟ ꜰɪʟᴇs ⋟ 250891
├⋟ ᴜsᴇᴅ sᴛᴏʀᴀɢᴇ ⋟ 140.59 MB
├⋟ ꜰʀᴇᴇ sᴛᴏʀᴀɢᴇ ⋟ 371.41 MB
│
├────[ 🤖 ʙᴏᴛ ᴅᴇᴛᴀɪʟs 🤖 ]────⍟   
│
├⋟ ᴜᴘᴛɪᴍᴇ ⋟ 5d 23h 34m 51s
├⋟ ʀᴀᴍ ⋟ 68.9%
├⋟ ᴄᴘᴜ ⋟ 1.6%   
│
╰─────────────────────⍟
```

- **Users/Groups/Files** — MongoDB se real-time count
- **Storage** — MongoDB `dbStats` se; `TOTAL_STORAGE_MB` env var se apne cluster ka quota
  batao (Atlas free tier = 512 MB by default)
- **Premium Users** — abhi 0 rahega kyunki premium system implement nahi hai (future feature)
- **Uptime/RAM/CPU** — Koyeb instance ka live resource usage

## User & Group Logging
Owner ko har naye user/group ka pata **LOG_CHANNEL** me chal jaata hai:

- Jab koi **naya user** pehli baar bot ko `/start` karta hai:
  ```
  #new_user

  👤 Name: <naam>
  🔗 Username: @<username>
  🆔 User ID: <id>
  ```
- Jab bot ko kisi **naye group** me add kiya jaata hai (authorized ho ya na ho):
  ```
  #new_group

  👥 Group: <group name>
  🆔 Group ID: <id>
  🔗 Link: <group ka invite link>
  ```
  (Agar group private hai aur bot abhi admin nahi hai, to link "N/A" dikhega — admin banate
  hi agli baar link mil jaayega.)

**Setup:** ek naya private channel banao, bot ko admin banao, uski ID `LOG_CHANNEL` env
variable me daal do.

## Anti-Spam System
Agar koi member group me ye bhejta hai:
- Koi bhi **link** (http/https/www/t.me)
- **@mention** (@username)
- **"bot"** keyword
- Ek **lamba bina-space spam word** (25+ characters)

To turant:
1. Message **auto-delete** ho jaata hai
2. User ko **warning** milti hai (1/3, 2/3, 3/3) group me hi
3. **4th baar** spam karne par user ko **MUTE_MINUTES** (default 30) ke liye **mute** kar diya
   jaata hai — us dauran wo group me kuch bhi likh nahi payega
4. Har spam event **SPAM_LOG_CHANNEL** (aapka private channel) me log ho jaata hai — user ka
   naam, ID, group, message, aur li gayi action ke saath

**Zaroori:** Bot ko group me **admin** banao aur "Delete Messages" + "Restrict/Ban Members"
permission do, warna delete/mute kaam nahi karega.

Group admins aur owner (`OWNER_ID`) is check se automatically **exempt** hote hain.

Agar patterns adjust karne ho (jaise "bot" keyword hata do, ya kisi aur spam pattern add
karo), to `bot.py` me `SPAM_PATTERNS` list edit kar sakte ho.

## "Request Your Movie" Button
Har auto-post ke niche ek **🔍 Request Your Movie** button hota hai. Jab koi member usse
click karta hai:

1. Bot ki PM khulti hai (deep-link ke through)
2. Bot member se movie/series ka naam-year type karne ko kehta hai
3. Jo bhi wo type karega, wo **seedhe REQUEST_CHANNEL** me chala jaata hai (uske Telegram
   naam/username/ID ke saath) — REQUEST_CHANNEL ek **private channel** hai jise sirf aap
   (admin) dekh sakte ho, members ko iska access nahi hota
4. Member ko confirmation mil jaata hai ki request bhej di gayi hai

**Setup:** ek naya private channel banao, bot ko usme admin banao, uski ID `REQUEST_CHANNEL`
env variable me daal do. Bas — members us channel ko dekh ya join nahi kar payenge, sirf
bot unki requests wahan post karega.

## Security — sirf Owner-authorized groups me bot kaam karega
Koi bhi random person bot ko apne group me add karke use nahi kar sakta. Jab bhi bot kisi
naye group me add hota hai:

1. Bot check karta hai ki wo group **authorized** hai ya nahi (MongoDB me stored list se)
2. Agar **nahi hai**, to bot ek warning message bhejta hai aur **khud hi group leave** kar
   deta hai
3. Sirf jin groups ko aap (owner) manually authorize karte ho, wahi bot me search/auto-filter
   kaam karega

**Owner-only commands** (sirf `OWNER_ID` wala user use kar sakta hai):
- `/addgroup` — jis group me bhejo, wahi authorize ho jaata hai (ya `/addgroup <chat_id>` kahin se bhi)
- `/removegroup` — group ko unauthorize karke bot khud leave kar leta hai
- `/listgroups` — saare authorized groups ki list dikhata hai

⚠️ **Zaroori:** `OWNER_ID` env variable me apna Telegram user ID zaroor daalo, warna ye
commands kaam nahi karenge (koi bhi inhe use nahi kar payega, aapke liye bhi lock ho jayenge).
Apna user ID pata karne ke liye Telegram par `@userinfobot` ko message karo.

## Broadcast (Owner-only) — Users + Groups, Auto-Delete Timer ke saath
Owner **kisi bhi message par reply karke** `/broadcast` bhejega, to wo message **sabhi
users** (jo kabhi bot ko `/start` kar chuke hain) aur **sabhi authorized groups** dono me
chala jaayega.

- `/broadcast` — jis message par reply karoge, wahi broadcast hoga (text, photo, video —
  kuch bhi chalega)
- `/setdeletetime <minutes>` — broadcast messages kitni der baad **auto-delete** hone chahiye,
  ye set karta hai (jaise `/setdeletetime 10` = 10 minute baad delete). `0` daalne se
  auto-delete **OFF** ho jaata hai.
- `/setdeletetime` (bina number ke) — abhi ka set kiya hua time dikha deta hai
- Broadcast ke dauran **live progress** dikhta hai (kitno ko bhej diya), aur end me
  **Sent / Failed** count ka summary milta hai
- Agar Telegram rate-limit (FloodWait) lagaye, to bot khud thoda ruk kar retry karta hai —
  broadcast crash nahi hota

**Note:** Auto-delete time ek baar set karne ke baad **sabhi future broadcasts** par apply
hota hai, jab tak aap dobara `/setdeletetime` se change na karo.

## Web Series Support (S01–S20)
Movie posts ke alawa ab **web series** ka bhi poora alag setup hai:

- Caption/filename me `S01`, `S02` ... `S20` (ya "Season 1") mile to bot use **series**
  samajhta hai
- Episode range **auto-detect** hota hai — chahe `E01-E08` ho, `E01-E05` ho, `E09-E16` ho,
  koi bhi fixed pattern nahi, jo bhi caption me likha ho wahi le liya jaata hai
- Har **season** ka **alag post** banta hai (Lucifer S01 aur Lucifer S02 do alag posts)
- Post me quality-wise group banta hai, har quality ke andar episode-ranges list hoti hain:

  ```
  🎬 Lucifer S01 #Combined
  ────•˚•── ✦ ──•˚•────
  🔊 ᴀᴜᴅɪᴏ  : Hindi
  🎭 ɢᴇɴʀᴇs : Action
  🍿 ᴏᴛᴛ : Amazon Prime Video
  🚀 ǫᴜᴀʟɪᴛʏ : WEB-DL
  ────•˚•── ✦ ──•˚•────

  ✧ 480p :
  E01-E08 [Click Here] (1.1 GB)
  E09-E16 [Click Here] (1.3 GB)

  ✧ 720p HEVC :
  E01-E08 [Click Here] (1.8 GB)
  E09-E16 [Click Here] (2.1 GB)

  💢 ᴘᴏᴡᴇʀᴇᴅ ʙʏ : [Your Channel] 🤞
  ```

- **Quality wahi dikhti hai jo caption me hai** — agar caption me "HEVC" likha hai to
  "480p HEVC" dikhega, nahi likha to sirf "480p" — koi guess nahi hota, seedha detect hota hai
- TMDB se is baar **TV Series** database use hota hai (movie database nahi) — isliye genre/OTT
  bhi series ke hisaab se sahi aayenge
- Movie posts bilkul pehle jaisi hi rahengi, koi change nahi

**Note:** Agar season pack me episode number bilkul na ho (jaise "Full Season" wali single
file), to us file ki line bina episode-label ke sirf `[Click Here] (size)` dikhegi.

## Naye tags add karne ho to
- `QUALITY_PATTERNS` — resolution/encode tags (bot.py me)
- `SOURCE_PATTERNS` — release source tags
- `LANGUAGES` — audio languages
- `GENRE_MAP` — TMDB genre ID → naam mapping

In sab me easily naye patterns/values add kar sakte ho.
